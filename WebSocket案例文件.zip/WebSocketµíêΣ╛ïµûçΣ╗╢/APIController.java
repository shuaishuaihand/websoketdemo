package com.ustcinfo.ishare.eip.si.screen.web.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.druid.support.json.JSONUtils;
import com.ustcinfo.ishare.eip.basic.system.web.BaseController;
import com.ustcinfo.ishare.eip.si.screen.web.endpoint.ElementWebSocketService;
import com.ustcinfo.ishare.eip.si.screen.web.endpoint.ScreenSkipService;
import com.ustcinfo.ishare.eip.si.screen.web.endpoint.WebSocketService;

/**
 * 大屏控制系统开放API Controller
 * 开放屏幕跳转接口，根据调用方传入的url信息进行大屏的跳转，
 * 跳转接口路径为:http://ip:port/screen/skip
 * 接口类型为post
 * @author w.tt
 * @version 2018-03-26
 */
@Controller
@RequestMapping(value = "/screen")
public class APIController extends BaseController {
	
	
	@Autowired
	private WebSocketService webSocketService; 
	@Autowired
	private ElementWebSocketService elementWebSocketService;
	
	@RequestMapping(value = "/skip")
	@ResponseBody
	public String skip(HttpServletRequest request, HttpServletResponse response) {
		ServletInputStream inputStream = null;
		BufferedReader br = null;
		String inBody = "";
		try {
			inputStream = request.getInputStream();
			if(inputStream == null) {
				return "";
			}
			br = new BufferedReader(new InputStreamReader(inputStream));
			String temp = null;
			while((temp = br.readLine()) != null ) {
				inBody += (temp + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("已经成功进入到切换");
		Map<String,String> inBodyMap = new HashMap<String,String>();
		inBodyMap = ScreenSkipService.getUrlByInBody(inBody);
		if(inBodyMap.get("sceneCode") != null && inBodyMap.get("layoutCode") != null && inBodyMap.get("iframeCode") != null && inBodyMap.get("url") != null) {
			String inBodyMessage = JSONUtils.toJSONString(inBodyMap);
			
			try {
				WebSocketService wss  = new WebSocketService(); 
				 Iterator<WebSocketService> iterator = webSocketService.webSocketSet.iterator();
				while(iterator.hasNext()) {
					wss = iterator.next();
					wss.sendMessage(inBodyMessage);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			return  ""
					+ "{" + "\n"
					+ "\"statusCode\":\"success\"" + ","+"\n"
					+ "\"statusDes\":\"调用跳转接口成功\"" +"\n"
					+ "}" + "\n";
		}
		return  ""
		+ "{" + "\n"
		+ "\"statusCode\":\"fail\"" +","+ "\n"
		+ "\"statusDes\":\"调用跳转接口失败，入参格式不正确！\"" +"\n"
		+ "}" + "\n";
		
		
	}
	
	
	
	/**
	 * 
	* @Function: APIController.java
	* @Description: 开放屏幕元素element控制接口，根据调用方传入的页面元素element信息进行大屏的跳转，
	* @param:描述1描述
	* @return：返回结果描述
	* @throws：异常描述
	*
	* @version: v1.0.0
	* @author: T.T.
	* @date: 2018年9月17日 下午10:03:16 
	*
	*
	 */
	@RequestMapping(value = "/elementSkip")
	@ResponseBody
	public String elementSkip(HttpServletRequest request, HttpServletResponse response) {
		ServletInputStream inputStream = null;
		BufferedReader br = null;
		String inBody = "";
		try {
			inputStream = request.getInputStream();
			if(inputStream == null) {
				return "";
			}
			br = new BufferedReader(new InputStreamReader(inputStream));
			String temp = null;
			while((temp = br.readLine()) != null ) {
				inBody += (temp + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("已经成功进入到切换");
		Map<String,String> inBodyMap = new HashMap<String,String>();
		inBodyMap = ScreenSkipService.getElementByInBody(inBody);
		if(inBodyMap.get("sceneCode") != null && inBodyMap.get("layoutCode") != null && inBodyMap.get("iframeCode") != null) {
			String inBodyMessage = JSONUtils.toJSONString(inBodyMap);
			
			try {	
				ElementWebSocketService wss  = new ElementWebSocketService(); 
				 Iterator<ElementWebSocketService> iterator = elementWebSocketService.webSocketSet.iterator();
				while(iterator.hasNext()) {
					wss = iterator.next();
					wss.sendMessage(inBodyMessage);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			return  ""
					+ "{" + "\n"
					+ "\"statusCode\":\"success\"" + ","+"\n"
					+ "\"statusDes\":\"调用页面元素点击事件成功\"" +"\n"
					+ "}" + "\n";
		}
		return  ""
		+ "{" + "\n"
		+ "\"statusCode\":\"failed\"" +","+ "\n"
		+ "\"statusDes\":\"调用页面元素点击事件失败,入参格式不正确!\"" +"\n"
		+ "}" + "\n";
		
		
	}
}
