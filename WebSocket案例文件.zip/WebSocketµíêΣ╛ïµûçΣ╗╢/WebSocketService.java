package com.ustcinfo.ishare.eip.si.screen.web.endpoint;
	import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.springframework.beans.factory.InitializingBean;

import com.alibaba.fastjson.JSONObject;
import com.ustcinfo.ishare.eip.si.screen.web.bean.ScreenFlag;

	/**
	 * @ServerEndpoint 注解是一个类层次的注解，它的功能主要是将目前的类定义成一个websocket服务器端,
	 * 注解的值将被用于监听用户连接的终端访问URL地址,客户端可以通过这个URL来连接到WebSocket服务器端
	 */
	@ServerEndpoint("/websocket")
	public class WebSocketService implements InitializingBean {
	    //静态变量，用来记录当前大屏数。应该把它设计成线程安全的。
	    private static int onlineCount = 0;

	    //concurrent包的线程安全Set，用来存放每个客户端对应的MyWebSocket对象。若要实现服务端与单一客户端通信的话，可以使用Map来存放，其中Key可以为用户标识
	    public static CopyOnWriteArraySet<WebSocketService> webSocketSet = new CopyOnWriteArraySet<WebSocketService>();

	    //与某个客户端的连接会话，需要通过它来给客户端发送数据
	    private Session session;
	    
		public static Map <String , ScreenFlag> screenFlagMap = new ConcurrentHashMap<String, ScreenFlag>();

	    
	    /**
	     * 连接建立成功调用的方法
	     * @param session  可选的参数。session为与某个客户端的连接会话，需要通过它来给客户端发送数据
	     */
	    @OnOpen
	    public void onOpen(Session session){
	        this.session = session;
	        webSocketSet.add(this);     //加入set中
	        addOnlineCount();           //大屏数加1
	        System.out.println("有新连接加入！当前大屏数为" + getOnlineCount());
	        String message = "连接建立";
	        for(WebSocketService item : webSocketSet) {
	        	try {
					item.sendMessage(message);
				} catch (Exception e) {
					e.printStackTrace();
				}
	        }
	    }

	    /**
	     * 连接关闭调用的方法
	     */
	    @OnClose
	    public void onClose(){
	        webSocketSet.remove(this);  //从set中删除
	        subOnlineCount();           //大屏数减1
	        screenFlagMap.remove(this.session.toString());
	        System.out.println("有一连接关闭！当前大屏数为" + getOnlineCount());
	    }

	    /**
	     * 收到客户端消息后调用的方法
	     * @param message 客户端发送过来的消息
	     */
	    @OnMessage
	    public void onMessage(String message) {
	        System.out.println("来自客户端的消息:" + message);
	        //群发消息
	        for(WebSocketService item: webSocketSet){
	            try {
					if(message.equals("ping")){
						item.sendMessage("ping");
					}else{
						item.sendMessage(message);
					}
	            } catch (IOException e) {
	                e.printStackTrace();
	                continue;
	            }
	        }
	    }

	    /**
	     * 发生错误时调用
	     * @param session
	     * @param error
	     */
	    @OnError
	    public void onError(Session session, Throwable error){
	        System.out.println("发生错误");
	        error.printStackTrace();
	    }

	    /**
	     * 这个方法与上面几个方法不一样。没有用注解，是根据自己需要添加的方法。
	     * @param message
	     * @throws IOException
	     */
//	    public void sendMessage(String message) throws IOException{
//	        this.session.getBasicRemote().sendText(message);
//	    }
	    public void sendMessage(String message) throws IOException{
	    	/**
	    	*以下都是实际业务的内容，根据业务进行编写
	    	**/

	    	if (message.indexOf("http") >=0) {
	    		JSONObject jsonObject = JSONObject.parseObject(message); 
		    	String url = jsonObject.get("url").toString();
		    	ScreenFlag screenFlag = screenFlagMap.get(this.session.toString());
		    	if(screenFlag != null) {
		    		if(url.indexOf("http://112.64.16.229:3012/?module") >=0) {
			    		int flag = screenFlagMap.get(this.session.toString()).getFlag();
			    		flag = flag+1;
			    		screenFlagMap.get(this.session.toString()).setFlag(flag);;
			    	}
		    	}else {
		    		screenFlag = new ScreenFlag();
		    		screenFlag.setFlag(0);
		    		screenFlag.setUrl(url);
		    		screenFlagMap.put(this.session.toString(),screenFlag);
		    	}
		    	if(screenFlagMap.get(this.session.toString()).getFlag() >=1) {
		    		if(url.indexOf("&center=country&u=voice&p=Shmcip@021") >=0 || url.indexOf("er=country") >=0){
		    			jsonObject.put("url", "http://112.64.16.229:3012/?module=demonstration.visualizations.shanghaiunicom&standalone=true&title=上海联通互联网业务质量监控%20-%20分布式质量监测平台&center=country");
		    			message = jsonObject.toJSONString();
		    		}else if(url.indexOf("&center=topology&u=voice&p=Shmcip@021") >= 0 ||  url.indexOf("er=topology") >=0){
		    			jsonObject.put("url","http://112.64.16.229:3012/?module=demonstration.visualizations.shanghaiunicom&standalone=true&title=上海联通互联网业务质量监控%20-%20分布式质量监测平台&center=topology");
		    			message = jsonObject.toJSONString();
		    		}else if(url.indexOf("&center=city&u=voice&p=Shmcip@021") >= 0 || url.indexOf("er=city") >= 0 ){
		    			jsonObject.put("url", "http://112.64.16.229:3012/?module=demonstration.visualizations.shanghaiunicom&standalone=true&title=上海联通互联网业务质量监控%20-%20分布式质量监测平台&center=city");
		    			message = jsonObject.toJSONString();
		    		}
		    		
		    	}else {
		    		if(url.indexOf("er=country") >=0){
		    			jsonObject.put("url", "http://112.64.16.229:3012/?module=demonstration.visualizations.shanghaiunicom&standalone=true&title=上海联通互联网业务质量监控%20-%20分布式质量监测平台&center=country&u=voice&p=Shmcip@021");
		    			message = jsonObject.toJSONString();
		    		}else if(url.indexOf("er=topology") >=0){
		    			jsonObject.put("url","http://112.64.16.229:3012/?module=demonstration.visualizations.shanghaiunicom&standalone=true&title=上海联通互联网业务质量监控%20-%20分布式质量监测平台&center=topology&u=voice&p=Shmcip@021");
		    			message = jsonObject.toJSONString();
		    		}else if(url.indexOf("er=city") >= 0 ){
		    			jsonObject.put("url", "http://112.64.16.229:3012/?module=demonstration.visualizations.shanghaiunicom&standalone=true&title=上海联通互联网业务质量监控%20-%20分布式质量监测平台&center=city&u=voice&p=Shmcip@021");
		    			message = jsonObject.toJSONString();
		    		}
		    	}
	    	}
	    	
	        this.session.getBasicRemote().sendText(message);
	    }
	    	
	    public static synchronized int getOnlineCount() {
	        return onlineCount;
	    }

	    public static synchronized void addOnlineCount() {
	        WebSocketService.onlineCount++;
	    }

	    public static synchronized void subOnlineCount() {
	        WebSocketService.onlineCount--;
	    }

		@Override
		public void afterPropertiesSet() throws Exception {
			
		}
	    
		public WebSocketService() {
		}
	    
}
